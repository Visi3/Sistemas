package pizzaria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Finalizar {
	
	public static Pedido pedido = new Pedido();
	public static Fim fim = new Fim();
	
	JFrame finalizar;
	JLabel T_valor1, T_valor2, T_valorB, T_total;
	JButton pix,debito, credito;
	
	double d_total, valor1M,valor2M,bebida,d_valorMetade1,d_valorMetade2,d_valorBebida;
	String valorMetade1, valorMetade2, valorBebida, total;
	
	public void finalizar() {
		
		// Realizando a soma total da compra 
		d_total =  d_valorMetade1 + d_valorMetade2 + d_valorBebida;
		
		//Tranformando os valores em Strings para apresentar em labels
		valorMetade1 = Double.toString(d_valorMetade1);
		valorMetade2 = Double.toString(d_valorMetade2);
		valorBebida = Double.toString(d_valorBebida);
		total = Double.toString(d_total);
		
		
		//Criando labels
		T_valor1 = new JLabel("Valor primeira metade: " + valorMetade1);
		T_valor1.setBounds(10, 0, 200, 50);
		
		T_valor2 = new JLabel("Valor segunda metade: " + valorMetade2);
		T_valor2.setBounds(10, 40, 200, 50);
		
		
		T_valorB = new JLabel("Valor bebida: " + valorBebida);
		T_valorB.setBounds(10, 80, 200, 50);
		
		
		T_total = new JLabel("Valor total: " + total);
		T_total.setBounds(10, 120, 200, 50);
		
		
		// Criando os botões com as formas de pagamento
		pix = new JButton("PIX");
		pix.setBounds(10, 200, 70, 30);
		pix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
								
				finalizar.dispose();
				fim.fim();

			}
		});
		
		
		debito = new JButton("Débito");
		debito.setBounds(90, 200, 80, 30);
		debito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
								
				finalizar.dispose();
				fim.fim();
			}
		});
		
		
		credito = new JButton("Crédito");
		credito.setBounds(180, 200, 80, 30);
		credito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
								
				finalizar.dispose();
				fim.fim();
			}
		});
		
		
		// Criando a penultima tela
		finalizar = new JFrame();
		finalizar.setTitle("Menu");
		finalizar.setSize(300,400);
		finalizar.setLocation(600, 100);
		finalizar.setLayout(null);
		finalizar.setVisible(true);
		
		
		//Adicionando os elementos a ultima tela
		finalizar.add(credito);
		finalizar.add(debito);
		finalizar.add(pix);
		finalizar.add(T_total);
		finalizar.add(T_valorB);
		finalizar.add(T_valor2);
		finalizar.add(T_valor1);
	}
}
