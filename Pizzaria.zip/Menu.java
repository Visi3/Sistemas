package pizzaria;

import javax.swing.*;

import java.awt.event.*;


public class Menu {
	
	//Criando as variaveis
	JFrame menu;
	JButton delivery,lacarte,balcao;
	
	public static Cadastro cadastro = new Cadastro();
	public static Pedido pedido = new Pedido();

	public static void main (String[] args) {
		//Criando o chama da classe
		Menu chama = new Menu();
		chama.menuMT();
		
	}
	
	public void menuMT() {
		
		// Botão balcão
		balcao = new JButton("Balcão");
		balcao.setBounds(95, 150, 100, 50);
		balcao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
						
				menu.dispose();
				cadastro.cadastro();

			}
		});
				
		// Botão à la carte
		lacarte = new JButton("À la carte");
		lacarte.setBounds(95, 80, 100, 50);
		lacarte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				menu.dispose();
				pedido.pedido();

			}
		});
		
		//Botão Delivery
		delivery = new JButton("Delivery");
		delivery.setBounds(95, 10, 100, 50);
		delivery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				menu.dispose();
				cadastro.cadastro();
			}
		});
		// Janela Menu
		menu = new JFrame();
		menu.setTitle("Menu");
		menu.setSize(300,400);
		menu.setLocation(600, 100);
		menu.setLayout(null);
		
		// Adicionando o botão a janela
		menu.add(delivery);
		menu.add(lacarte);
		menu.add(balcao);
		
		
		menu.setVisible(true);
		
	}
}
