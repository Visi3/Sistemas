package pizzaria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cadastro {
	JFrame cadastro;
	JLabel nomeTexto,celularTexto,ruaTexto,numeroTexto,bairroTexto;
	JTextField nomeCaixa, celularCaixa, ruaCaixa, numeroCaixa, bairroCaixa;
	JButton realizarPeido;
	
	public static Pedido pedido = new Pedido();

	public void cadastro() {

		//Adicionando labels
		nomeTexto = new JLabel("Nome:");
		nomeTexto.setBounds(10, 0, 100, 50);
	
	
		nomeCaixa = new JTextField();
		nomeCaixa.setBounds(60, 16, 170, 25);
	
	
		celularTexto = new JLabel("Celular:");
		celularTexto.setBounds(10, 40, 100, 50);
	
	
		celularCaixa = new JTextField();
		celularCaixa.setBounds(60, 56, 170, 25);
	
	
		ruaTexto = new JLabel("Rua:");
		ruaTexto.setBounds(10, 80, 100, 50);
	
	
		ruaCaixa = new JTextField();
		ruaCaixa.setBounds(60, 96, 170, 25);
	
	
		numeroTexto = new JLabel("Número:");
		numeroTexto.setBounds(10, 120, 100, 50);
	
	
		numeroCaixa = new JTextField();
		numeroCaixa.setBounds(60, 136, 60, 25);
	
	
		bairroTexto = new JLabel("Bairro:");
		bairroTexto.setBounds(10, 160, 100, 50);
	
	
		bairroCaixa = new JTextField();
		bairroCaixa.setBounds(60, 176, 170, 25);
	
			
		// Botão balcão
		realizarPeido = new JButton("Realizar Pedido");
		realizarPeido.setBounds(80, 210, 130, 40);
		realizarPeido.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
							
			cadastro.dispose();
			pedido.pedido();

		}
	});
	
	
	//Janela cadastro
	cadastro = new JFrame();
	cadastro.setTitle("Cadastro");
	cadastro.setSize(300,400);
	cadastro.setLocation(600, 100);
	cadastro.setVisible(true);
	cadastro.setLayout(null);
	
	
	//Adicionando a tela
	cadastro.add(bairroCaixa);
	cadastro.add(bairroTexto);
	cadastro.add(realizarPeido);
	cadastro.add(numeroTexto);
	cadastro.add(numeroCaixa);
	cadastro.add(ruaTexto);
	cadastro.add(ruaCaixa);
	cadastro.add(celularTexto);
	cadastro.add(celularCaixa);
	cadastro.add(nomeTexto);
	cadastro.add(nomeCaixa);
	
	}
}

