package pizzaria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Fim {
	
	public static Menu menu = new Menu();
	public static Finalizar finalizar = new Finalizar();
	public static Pedido pedido = new Pedido();
	
	JFrame fim;
	JLabel msgFinal;
	JButton voltaMenu;
	
	public void fim() {
		
		// label com ultima mensagem
		msgFinal = new JLabel("Pedido realizado!");
		msgFinal.setBounds(95,10,120,20);
		
		//Cirando botão final para voltar ao menu
		voltaMenu = new JButton("Menu");
		voltaMenu.setBounds(105, 80, 70, 30);
		voltaMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
								
				fim.dispose();
				menu.menuMT();

			}
		});
		
		//Criando tela final
		fim = new JFrame();
		fim.setTitle("Realizado");
		fim.setSize(300,200);
		fim.setLocation(600, 100);
		fim.setLayout(null);
		fim.setVisible(true);
		
		//Adicionando os elementos a tela final
		fim.add(voltaMenu);
		fim.add(msgFinal);
	}
}
