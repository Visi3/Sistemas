package pizzaria;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Pedido {
	JFrame pedido;
	JLabel saboresSalgado, bebidas,saboresDoce, metade1Texto, metade2Texto, bebidaTexto;
	JTextField metade1Caixa, metade2Caixa, bebidaCaixa;
	JButton finalizarPedido;
	
	String metade1, metade2, bebida;
	int i_metade1,i_metade2,i_bebida, cod;
	
	public static Finalizar finalizar = new Finalizar();
	public static Menu menu = new Menu();
	
	
	public void pedido() {
		//Criando as labels
		saboresSalgado = new JLabel("<html>SALGADAS: <br><br>0 - Pizza sem recheio 10,00 <br> 1 - 4 queijos 15,00 <br> 2 - Strogonoff 16,00 <br> 3 - Filé na mostarda 16,00 <br> 4 - Rúcula 10,00 <br> 5 - Frango com catupiry 12,00 <br> 6 - Marguerita 10,00 <br> 7 - Palmito 12,00 <br> 8 - Peperone 12,00 <br> 9 - Baiana 13,00 <br> 10 - Espinafre 11,00 </html>");
		saboresSalgado.setBounds(10, 10, 200, 200);
		
		
		saboresDoce = new JLabel("<html>DOCES: <br><br>11 - Sensação 13,00 <br> 12 - Sedução 12,00 <br> 13 - Romeu e Julieta 14,00 <br> 14 - Banofe 10,00 <br> 15 - Sorvete 12,00 <br> 16 - Avelã 14,00 <br> 17 - Frutas 12,00 <br> 18 - Prestigio 11,00 <br> 19 - Califórnia 13,00 <br> 20 - Chocolate Branco 11,00 </html>");
		saboresDoce.setBounds(178, 10, 200, 200);
		
		bebidas = new JLabel("<html>BEBIDAS: <br> 0 - Sem bebida <br> 21 - Água sem gás 3,00 <br> 22 - Água com gás 4,00 <br> 23 - Refrigerante lata 4,00 <br> 24 - Refrigerante 2 litros 7,00 <br> 25 - Suco de laranja 5,00 </html>");
		bebidas.setBounds(10, 180, 200, 200);
		
		metade1Texto = new JLabel("Primeira metade:");
		metade1Texto.setBounds(10, 360, 100, 50);
		
		
		metade1Caixa = new JTextField();
		metade1Caixa.setBounds(110, 377, 30, 20);
		
		
		metade2Texto = new JLabel("Segunda metade:");
		metade2Texto.setBounds(170, 360, 100, 50);
		
		
		metade2Caixa = new JTextField();
		metade2Caixa.setBounds(275, 377, 30, 20);
		
		
		bebidaTexto = new JLabel("Bebida:");
		bebidaTexto.setBounds(110, 400, 100, 50);
		
		
		bebidaCaixa = new JTextField();
		bebidaCaixa.setBounds(160, 417, 30, 20);
		
		//Adicionando o botão
		finalizarPedido = new JButton("Finalizar Pedido");
		finalizarPedido.setBounds(100, 450, 130, 40);
		finalizarPedido.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				//Retirando a tela atual
				pedido.dispose();
				
				//Mudando as variaveis de String para Inteiro
				metade1  = metade1Caixa.getText();	
				i_metade1 = Integer.parseInt(metade1);
				
				metade2 = metade2Caixa.getText();
				i_metade2 = Integer.parseInt(metade2);
				
				bebida = bebidaCaixa.getText();
				i_bebida = Integer.parseInt(bebida);
				
				// Chamando o método casos para a soma dos valores de acordo com as escolhas
				casos();
				//Chamando penultima tela
				if (cod == 1) {
					finalizar.d_valorMetade1 = 0;
					finalizar.d_valorMetade2 = 0;
					finalizar.d_valorBebida = 0;
					cod = 0;
					
					menu.menuMT();
				}else {
					finalizar.finalizar();
				}
				
			}
		});
		
		// Criando tela pedido 
		pedido = new JFrame();
		pedido.setTitle("Pedido");
		pedido.setSize(350,550);
		pedido.setLocation(600, 100);
		pedido.setVisible(true);
		pedido.setLayout(null);
		
		
		//Adicionando os elementos a tela pedido
		pedido.add(finalizarPedido);
		pedido.add(bebidaCaixa);
		pedido.add(bebidaTexto);
		pedido.add(metade2Caixa);
		pedido.add(metade2Texto);
		pedido.add(metade1Caixa);
		pedido.add(metade1Texto);
		pedido.add(bebidas);
		pedido.add(saboresSalgado);
		pedido.add(saboresDoce);
	}
	public void casos() {
		// Diversos Switch cases para verificar as escolhas
		switch (i_metade1) {
			case 0:
				break;
			case 1:
				
				finalizar.d_valorMetade1 = 15.00;
				break;
			case 2:
			
				finalizar.d_valorMetade1 = 16.00;
				break;
			case 3:
			
				finalizar.d_valorMetade1 = 16.00;
				break;
			case 4:
				
				finalizar.d_valorMetade1 = 10.00;
				break;
			case 5:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 6:
				
				finalizar.d_valorMetade1 = 10.00;
				break;
			case 7:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 8:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 9:
				
				finalizar.d_valorMetade1 = 13.00;
				break;
			case 10:
				
				finalizar.d_valorMetade1 = 11.00;
				break;
			case 11:
				
				finalizar.d_valorMetade1 = 13.00;
				break;
			case 12:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 13:
				
				finalizar.d_valorMetade1 = 14.00;
				break;
			case 14:
				
				finalizar.d_valorMetade1 = 10.00;
				break;
			case 15:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 16:
				
				finalizar.d_valorMetade1 = 14.00;
				break;
			case 17:
				
				finalizar.d_valorMetade1 = 12.00;
				break;
			case 18:
				
				finalizar.d_valorMetade1 = 11.00;
				break;
			case 19:
				
				finalizar.d_valorMetade1 = 13.00;
				break;
			case 20:
				
				finalizar.d_valorMetade1 = 11.00;
				break;
			default:
				//Mensagem que apresenta erro ao fazer uma escolha inválida
				JOptionPane.showMessageDialog(null,"Opção inválida na primeira metade, realizar pedido novamente!");
				cod = 1;
		}	
				
		switch (i_metade2) {
		// Diversos Switch cases para verificar as escolhas
			case 0:
				finalizar.d_valorMetade2 = 5.00;
				break;
			case 1:
				
				finalizar.d_valorMetade2 = 15.00;
				break;
			case 2:
				
				finalizar.d_valorMetade2 = 16.00;
				break;
			case 3:
				
				finalizar.d_valorMetade2 = 16.00;
				break;
			case 4:
				
				finalizar.d_valorMetade2 = 10.00;
				break;
			case 5:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 6:
				
				finalizar.d_valorMetade2 = 10.00;
				break;
			case 7:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 8:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 9:
				
				finalizar.d_valorMetade2 = 13.00;
				break;
			case 10:
				
				finalizar.d_valorMetade2 = 11.00;
				break;
			case 11:
				
				finalizar.d_valorMetade2 = 13.00;
				break;
			case 12:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 13:
				
				finalizar.d_valorMetade2 = 14.00;
				break;
			case 14:
				
				finalizar.d_valorMetade2 = 10.00;
				break;
			case 15:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 16:
				
				finalizar.d_valorMetade2 = 14.00;
				break;
			case 17:
				
				finalizar.d_valorMetade2 = 12.00;
				break;
			case 18:
				
				finalizar.d_valorMetade2 = 11.00;
				break;
			case 19:
				
				finalizar.d_valorMetade2 = 13.00;
				break;
			case 20:
				
				finalizar.d_valorMetade2 = 11.00;
				break;
			default:
				//Mensagem que apresenta erro ao fazer uma escolha inválida
				JOptionPane.showMessageDialog(null,"Opção inválida na segunda metade, realizar pedido novamente!");
				cod = 1;
		}
		
		switch (i_bebida) {
			case 0:
				finalizar.d_valorMetade1 = 0;
				break;
			case 21:
				
				finalizar.d_valorBebida = 3.00;
				break;
			case 22:
				
				finalizar.d_valorBebida = 4.00;
				break;
			case 23:
				
				finalizar.d_valorBebida = 4.00;
				break;
			case 24:
				
				finalizar.d_valorBebida = 7.00;
				break;
			case 25:
				
				finalizar.d_valorBebida = 5.00;
				break;
			default:
				//Mensagem que apresenta erro ao fazer uma escolha inválida
				JOptionPane.showMessageDialog(null,"Opção inválida para bebida, realizar pedido novamente!");
				cod = 1;
		}
	}
}

