package Passagens;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Bilhete {
	JFrame bilhete;
	String classe,horario,destino,nome,cpf,companhia,valorTS,valorBS,valorPS,valorCS,valor;
	double valorT, valorClasse, valorPassagem, valorBagagem;
	int codigoI;
	JButton finalizar;
	
	JLabel classeT,horarioT,destinoT,nomeT,cpfT,companhiaT,codigoVooT,valorTT,valorBT,valorPT,valorCT;
	
	
	public static Rota rota = new Rota();
	public static Comprovante comprovante = new Comprovante();
	
	public void bilhete(){
		// cirnaod o objeto random para criar um código de voo
		Random random = new Random();
		
		codigoI = random.nextInt(1000,9999);
		codigoVooT = new JLabel("BR" + String.valueOf(codigoI));
		codigoVooT.setBounds(110,10,100,30);
		
		
		// criando labels
		destinoT = new JLabel(destino);
		destinoT.setBounds(60, 30, 200, 150);
		
		nomeT = new JLabel("Nome: " + nome);
		nomeT.setBounds(10, 170, 300, 40);
		
		cpfT = new JLabel ("CPF: " + cpf);
		cpfT.setBounds(10, 190, 200, 40);
		
		companhiaT = new JLabel("Companhia: " + companhia);
		companhiaT.setBounds(10, 210, 200, 40);
		
		horarioT = new JLabel("Horário: " + horario);
		horarioT.setBounds(10, 230, 100, 40);
		
		classeT = new JLabel("Classe: " + classe);
		classeT.setBounds(10, 250, 200, 40);
		
		valorPS = Double.toString(valorPassagem);
		valorPT = new JLabel("Passagem: " + valorPS);
		valorPT.setBounds(10, 300, 100, 40);
		
		valorCS = Double.toString(valorClasse);
		valorCT = new JLabel("Classe: " + valorCS);
		valorCT.setBounds(10, 320, 100, 40);
		
		valorBS = Double.toString(valorBagagem);
		valorBT = new JLabel("Bagagem: " + valorBS);
		valorBT.setBounds(10, 340, 100, 40);
		
		valorTS = Double.toString(valorT);
		valorTT = new JLabel("Total: " + valorTS);
		valorTT.setBounds(150, 320, 100, 40);
		
		finalizar = new JButton("Finalizar");
		finalizar.setBounds(90, 400, 100, 30);
		finalizar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				bilhete.dispose();
				comprovante.comprovante();
				
			}
		});
		
		
		
		
		bilhete = new JFrame();
		bilhete.setTitle("Bilhete");
		bilhete.setSize(300,500);
		bilhete.setLocation(600, 100);
		bilhete.setLayout(null);
		
		
		bilhete.add(codigoVooT);
		bilhete.add(classeT);
		bilhete.add(destinoT);
		bilhete.add(nomeT);
		bilhete.add(cpfT);
		bilhete.add(horarioT);
		bilhete.add(companhiaT);
		bilhete.add(valorTT);
		bilhete.add(valorBT);
		bilhete.add(valorCT);
		bilhete.add(valorPT);
		bilhete.add(finalizar);
				
		
		
		bilhete.setVisible(true);
	}
}
