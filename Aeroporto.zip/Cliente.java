package Passagens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cliente {
	JFrame cadastro;
	JLabel nomeT,celularT,ruaT,numeroT,bairroT,rgT,cpfT,dataNT,cidadeT,estadoT,paisT;
	JTextField nomeC,ruaC,celularC,numeroC,bairroC,rgC,cpfC,dataNC,cidadeC,estadoC,paisC;
	JButton cadastrar;
	
	//Criando o objeto para chamar a proxima classe
	public static Passagem passagem = new Passagem();
	public static Bilhete bilhete = new Bilhete();
	
	public void cadastro(){
		//Adicionando Labels
		nomeT = new JLabel("Nome:");
		nomeT.setBounds(10, 0, 100, 50);
		
		
		nomeC = new JTextField();
		nomeC.setBounds(90, 16, 170, 25);
		
		
		celularT = new JLabel("Celular:");
		celularT.setBounds(10, 40, 100, 50);
		
		
		celularC = new JTextField();
		celularC.setBounds(90, 56, 170, 25);
		
		
		dataNT = new JLabel("<html>Data<br>Nascimento:</html>");
		dataNT.setBounds(10, 80, 100, 50);
		
		
		dataNC = new JTextField();
		dataNC.setBounds(90, 96, 170, 25);
		
		
		rgT = new JLabel("RG:");
		rgT.setBounds(10, 120, 100, 50);
		
		
		rgC = new JTextField();
		rgC.setBounds(90, 136, 60, 25);
		
		
		cpfT = new JLabel("CPF:");
		cpfT.setBounds(10, 160, 100, 50);
		
		
		cpfC = new JTextField();
		cpfC.setBounds(90, 176, 170, 25);
		
		
		ruaT = new JLabel("Rua:");
		ruaT.setBounds(10, 200, 100, 50);
		
		
		ruaC = new JTextField();
		ruaC.setBounds(90, 216, 170, 25);
		
		
		numeroT = new JLabel("Número:");
		numeroT.setBounds(10, 240, 100, 50);
		
		
		numeroC = new JTextField();
		numeroC.setBounds(90, 256, 170, 25);
		
		
		bairroT = new JLabel("Bairro:");
		bairroT.setBounds(10, 280, 100, 50);
		
		
		bairroC = new JTextField();
		bairroC.setBounds(90, 296, 170, 25);
		
		
		cidadeT = new JLabel("Cidade:");
		cidadeT.setBounds(10, 320, 100, 50);
		
		
		cidadeC = new JTextField();
		cidadeC.setBounds(90, 336, 170, 25);
		
		
		estadoT = new JLabel("Estado:");
		estadoT.setBounds(10, 360, 100, 50);
		
		
		estadoC = new JTextField();
		estadoC.setBounds(90, 376, 170, 25);
		
		
		paisT = new JLabel("País:");
		paisT.setBounds(10, 400, 100, 50);
		
		
		paisC = new JTextField();
		paisC.setBounds(90, 416, 170, 25);
		
		//Botão de cadastro
		cadastrar = new JButton("Cadastrar");
		cadastrar.setBounds(65, 486, 140, 40);
		cadastrar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				
				passagem.nomeS = nomeC.getText();
				passagem.cpfS = cpfC.getText();
				
				
				cadastro.dispose();
				passagem.passagem();
				
				
				
			}
		});
		
		
		
		
		
		// Criando tela
		cadastro = new JFrame();
		cadastro.setTitle("Principal");
		cadastro.setSize(300,600);
		cadastro.setLocation(600, 100);
		cadastro.setLayout(null);
		
		
		//Adicionando elementos
		cadastro.add(cadastrar);
		cadastro.add(cidadeC);
		cadastro.add(cidadeT);
		cadastro.add(estadoT);
		cadastro.add(estadoC);
		cadastro.add(paisC);
		cadastro.add(paisT);
		cadastro.add(bairroC);
		cadastro.add(bairroT);
		cadastro.add(numeroT);
		cadastro.add(numeroC);
		cadastro.add(ruaT);
		cadastro.add(ruaC);
		cadastro.add(dataNC);
		cadastro.add(dataNT);
		cadastro.add(cpfC);
		cadastro.add(cpfT);
		cadastro.add(rgC);
		cadastro.add(rgT);
		cadastro.add(celularT);
		cadastro.add(celularC);
		cadastro.add(nomeT);
		cadastro.add(nomeC);
		
		cadastro.setVisible(true);
	}
}
