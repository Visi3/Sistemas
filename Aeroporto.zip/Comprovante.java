package Passagens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Comprovante {
	JFrame comprovante;
	JLabel msgFinal;
	JButton voltar;
	
	public static Principal principal = new Principal();
	
	public void comprovante() {
		// apresentando msg final comprovando a venda
		msgFinal = new JLabel("Passagem vendida com sucesso!");
		msgFinal.setBounds(40, 20, 200, 40);
		
		voltar = new JButton("Voltar");
		voltar.setBounds(100, 80, 80, 30);
		voltar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				comprovante.dispose();
				principal.principal();
				
			}
		});
		
		
		comprovante = new JFrame();
		comprovante.setTitle("Comprovante");
		comprovante.setSize(300,200);
		comprovante.setLocation(600, 100);
		comprovante.setLayout(null);
		
		comprovante.add(msgFinal);
		comprovante.add(voltar);
		
		comprovante.setVisible(true);
	}
}
