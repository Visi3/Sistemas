package Passagens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Passagem {
	JFrame passagem;
	JLabel destinoT,companhiaT,horarioT,classeT;
	JTextField destinoC,companhiaC,horarioC,classeC;
	JButton verificarR;
	
	String destinoR,classeB,horarioB,companhiaB,nomeS,cpfS;
	int destinoI, classeI,horarioI,companhiaI,cod = 0;
	
	
	public static Rota rota = new Rota();
	public static Bilhete bilhete = new Bilhete();
	
	public void passagem() {
		
		//Adicionando Labels
		destinoT = new JLabel("<html>DESTINO:<br>1 - São Paulo R$879<br>2 - Porto Alegre R$ 558,00<br>3 - Salvador R$ 775,00 <br>Taxa de serviço e embarque inclusos no valor</html>");
		destinoT.setBounds(10, 0, 300, 100);
		
		destinoC = new JTextField();
		destinoC.setBounds(10, 100, 30, 20);
		
		
		companhiaT = new JLabel("<html>COMPANHIA:<br>1 - Azul<br>2 - Gol<br>3 - Latam</html>");
		companhiaT.setBounds(10, 120, 300, 100);
		
		companhiaC = new JTextField();
		companhiaC.setBounds(10, 210, 30, 20);
		
		
		horarioT = new JLabel("<html>HORÁRIO:<br>1 - 9:00<br>2 - 14:00<br>3 - 20:00</html>");
		horarioT.setBounds(10, 240, 300, 100);
		
		horarioC = new JTextField();
		horarioC.setBounds(10, 330, 30, 20);
		
		
		classeT = new JLabel("<html>CLASSE:<br>1 - Primeira R$ 600<br>2 - Executiva R$300<br>3 - Econômica R$0 </html>");
		classeT.setBounds(10, 350, 300, 100);
		
		classeC = new JTextField();
		classeC.setBounds(10, 440, 30, 20);
		
		
		
		verificarR = new JButton("Vender Passagens");
		verificarR.setBounds(65,480,160,40);
		verificarR.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent evt) {
				//Tranformando a opção em inteiro para o switch case
				destinoR = destinoC.getText();
				destinoI = Integer.parseInt(destinoR);
				
				classeB = classeC.getText();
				classeI = Integer.parseInt(classeB);
				
				horarioB = horarioC.getText();
				horarioI = Integer.parseInt(horarioB);
				
				companhiaB = companhiaC.getText();
				companhiaI = Integer.parseInt(companhiaB);
				
				destino();
				// Caso seja uma opção errada ele continua na pagina
				if(cod != 1) {
					rota.nomeS = nomeS;
					rota.cpfS = cpfS;
					
					passagem.dispose();
					rota.rota();
				} else {
					passagem();
				}
				
			}
		});
		
		
		// criando tela
		passagem = new JFrame();
		passagem.setTitle("Entrada");
		passagem.setSize(300,600);
		passagem.setLocation(600, 100);
		passagem.setLayout(null);
		
		
		passagem.add(verificarR);
		passagem.add(destinoT);
		passagem.add(destinoC);
		passagem.add(companhiaC);
		passagem.add(companhiaT);
		passagem.add(horarioT);
		passagem.add(horarioC);
		passagem.add(classeC);
		passagem.add(classeT);
		
		passagem.setVisible(true);
	}
	public void destino() {
		// Case para destino
		switch (destinoI){
			case 1:
				rota.rotaS = "<html>---------TRAJETO---------<br>Cascavel   1h 20m   Curitiba<br><br>Troca de aeronaves<br>Espera: 00h 55m<br><br>Curitiba   01h 05m   São Paulo<br>---------------------------------</html>";
				rota.valorT =  rota.valorT + 879.00;
				rota.valorP = 879.00;
				break;
			case 2:
				rota.rotaS = "<html>---------TRAJETO---------<br>Cascavel   1h 20m   Curitiba<br><br>Troca de aeronaves<br>Espera: 1h 55m<br><br>Curitiba   01h 15m   Porto Alegre<br>---------------------------------</html>";
				rota.valorT =  rota.valorT + 558.00;
				rota.valorP = 558.00;
				break;
			case 3:
				rota.rotaS = "<html>---------TRAJETO---------<br>Cascavel   1h 20m   Campinas<br><br>Troca de aeronaves<br>Espera: 1h 35m<br><br>Campinas  02h 20m   Salvador<br>---------------------------------</html>";
				rota.valorT =  rota.valorT + 775.00;
				rota.valorP = 775.00;
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida para destino!", "DESTINO INVÁLIDO", JOptionPane.ERROR_MESSAGE);
				cod = 1;
		}
		// case para classe
		switch (classeI) {
			case 1:
				rota.classeS = "Executiva";
				rota.valorT =  rota.valorT + 600.00;
				rota.valorC = 600.00;
				break;
			case 2:
				rota.classeS = "Primeira Classe";
				rota.valorT =  rota.valorT + 300.00;
				rota.valorC = 300.00;
				break;
			case 3:
				rota.classeS = "Econômica";
				rota.valorT =  rota.valorT + 0;
				rota.valorC = 0;
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida para classe!", "CLASSE INVÁLIDA", JOptionPane.ERROR_MESSAGE);
				cod = 1;
		}
		//case para horario
		switch(horarioI) {
			case 1:
				rota.horarioS = "9:00";
				break;
			case 2:
				rota.horarioS = "14:00";
				break;
			case 3:
				rota.horarioS = "20:00";
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida para horário!", "HORÁRIO INVÁLIDO", JOptionPane.ERROR_MESSAGE);
				cod = 1;
		}
		//case para companhia
		switch(companhiaI) {
			case 1:
				rota.companhiaS = "Azul";
				break;
			case 2:
				rota.companhiaS = "Gol";
				break;
			case 3:
				rota.companhiaS = "Latam";
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida para companhia!", "COMPANHIA INVÁLIDA", JOptionPane.ERROR_MESSAGE);
				cod = 1;
					
		}
	}
}
