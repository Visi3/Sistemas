package Passagens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


public class Principal {
	JFrame principal;
	JButton vender;
	
	public static Cliente cliente = new Cliente();
	
	public void principal() {
		
		//Criando botão para iniciar a venda
		vender = new JButton("Vender Passagem");
		vender.setBounds(65, 50, 150, 30);
		vender.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent evt) {
				principal.dispose();
				cliente.cadastro();
				
			}
		});
		
		//Criando JFrame
		principal = new JFrame();
		principal.setTitle("Principal");
		principal.setSize(300,200);
		principal.setLocation(600, 100);
		principal.setLayout(null);
		
		principal.add(vender);
		
		principal.setVisible(true);
	}
}
