package Passagens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Rota {
	JLabel rotaT,bagagemT,msg;
	JTextField bagagemC;
	JButton bilheteB;
	
	JFrame rota;
	String rotaS,horarioS,classeS,companhiaS,nomeS,cpfS;
	double valorT,valorC,valorP;
	
	
	// criando objeto para chamar as classes
	public static Passagem passsagem = new Passagem();
	public static Bilhete bilhete = new Bilhete();
	
	public void rota() {
		// criando labels
		rotaT = new JLabel(rotaS);
		rotaT.setBounds(70, 10, 200, 150);
		
		bagagemT = new JLabel("Quantidade de bagagens:    1 = 160,00");
		bagagemT.setBounds(20, 175, 300, 25);
		
		bagagemC = new JTextField();
		bagagemC.setBounds(20, 200, 50, 20);
		
		msg = new JLabel("<html>Bagagem de mão e média<br>já estão inclusas no valor da passagem");
		msg.setBounds(20, 230, 200, 50);
		
		
		bilheteB = new JButton("Finalizar passagem");
		bilheteB.setBounds(65,300,160,40);
		bilheteB.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent evt) {
				// passando os valores para a classe bilhete 
				bilhete.valorT = valorT + (Double.parseDouble(bagagemC.getText()) * 160.00);
				bilhete.valorBagagem = Double.parseDouble(bagagemC.getText()) * 160.00;
				bilhete.valorClasse = valorC;
				bilhete.valorPassagem = valorP;
				
				
				bilhete.destino = rotaS;
				bilhete.companhia = companhiaS;
				bilhete.classe = classeS;
				bilhete.cpf = cpfS;
				bilhete.nome = nomeS;
				bilhete.horario = horarioS;
				
				
				rota.dispose();
				bilhete.bilhete();
			
			}
		});
		
		
		
		rota = new JFrame();
		rota.setTitle("Principal");
		rota.setSize(300,400);
		rota.setLocation(600, 100);
		rota.setLayout(null);
		
		
		rota.add(rotaT);
		rota.add(bagagemT);
		rota.add(bagagemC);
		rota.add(bilheteB);
		rota.add(msg);
		
		
		rota.setVisible(true);
	}
}
