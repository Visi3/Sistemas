package Passagens;

import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Entrada {
	JFrame entrada;
	JTextField idTF;
	JPasswordField senhaPF;
	JLabel idL, senhaL;
	JButton entrar; 
	
	int idInt, senhaInt;
	
	String idConfirm, senhaConfirm;
	char[] senhaChar;
	
	//Criando o objeto para chamar a próxima classe
	public static Principal principal = new Principal();
	
	
	
	public static void main (String[] args) {
		//Criando o chama da classe
		Entrada chama = new Entrada();
		chama.entrada();
		
	}
	
	public void entrada() {
		
		//Direcionando os elementos para os lugares da tela
		idL = new JLabel("Id Funcionário:  (01)");
		idL.setBounds(10,20,150,50);
		
		idTF = new JTextField();
		idTF.setBounds(10,60,150,20);
		
		
		senhaL = new JLabel("Senha:   (123)");
		senhaL.setBounds(10,80,100,50);
		
		senhaPF = new JPasswordField();
		senhaPF.setBounds(10,120,150,20);
		
		
		entrar = new JButton("Entrar");
		entrar.setBounds(100, 180, 80, 30);
		entrar.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent evt) {
				
				//Pegando as informações da caixa id e passando para inteiro
				idConfirm = idTF.getText();
				idInt = Integer.parseInt(idConfirm);
				
				//Pegando as informações da caixa senha e passando para inteiro
				senhaChar = senhaPF.getPassword();
				senhaConfirm = String.copyValueOf(senhaChar);
				senhaInt = Integer.parseInt(senhaConfirm);
				
				if (idInt == 01 & senhaInt == 123) {
					// Desfazendo a tela de entrada e chamando a tela principal
				entrada.dispose();
				principal.principal();
		
					
				} else{
					//Mensagem de erro caso o id ou senha estejam errrados
					JOptionPane.showMessageDialog(null, "Id ou senha incorreto!");
					
				}
				
				
				
			}
		});
		
		//Criando a tela e inserindo suas informações 
		entrada = new JFrame();
		entrada.setTitle("Entrada");
		entrada.setSize(300,300);
		entrada.setLocation(600, 100);
		entrada.setLayout(null);
		
		//Adicionando os elementos para a tela de entrada
		entrada.add(entrar);
		entrada.add(senhaL);
		entrada.add(senhaPF);
		entrada.add(idTF);
		entrada.add(idL);
		
		//Deixando a tela visivel
		entrada.setVisible(true);
		
	}
	
}
